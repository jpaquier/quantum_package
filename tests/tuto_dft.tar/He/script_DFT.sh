. ~/programs/qp_barth_last/quantum_package/quantum_package.rc
ezfio=$1
# expectations : 
#               $1 is a ezfio folder with a orthonormal orbitals (HF, DFT, etc ...)
#               and a near FCI wave function 

# Loading the environment variables 

# a few inputs for the DFT in the basis set  ...

##### the potential in the basis set  
# If set to "T", defines the interaction in the basis set with a simple HF potential 
# If set to "F", defines the interaction in the basis set with the wave function stored in the ezfio folder 
# !!!! ==> "F" much slower than "T" for large basis set !!!! 

hf_potential="T"
echo $hf_potential > ${ezfio}/dft_keywords/basis_set_hf_potential


##### the functionnal used for the DFT 
# "basis_set_LDA"            :: corresponds to a simple LDA approximation : quite fast but tends to over correlate 
# "basis_set_on_top_PBE"     :: corresponds to a mixing between on-top 2 body dm and PBE with a correction to the on top : quite slow but very good
functional="basis_set_on_top_PBE"
echo $functional  > ${ezfio}/dft_keywords/md_correlation_functional

qp_run print_e_components_dft_mu_of_r $ezfio | tee ${ezfio}.DFT.out 


# output : 
echo 
echo 
echo 
# Be aware that such an energy is based on the VARIATIONAL ENERGY OF PSI, so if it contains some non variational part as PT2 corrections for instance, it is a biased estimation of the FCI energy
echo "FINAL TOTAL ENERGY = "
grep "TOTAL ENERGY CORR"  ${ezfio}.DFT.out | tail -1 | cut -d "=" -f 2
# TOTAL CORRECTION FOR THE DFT ENERGY 
echo "DFT mu(r)     correlation ="
grep "DFT mu(r)     correlation ="  ${ezfio}.DFT.out | tail -1 | cut -d "=" -f 2
echo "DFT mu(r) correlation corr"
grep "DFT mu(r) correlation corr"   ${ezfio}.DFT.out | tail -1 | cut -d "=" -f 2

# Average mu 
echo "mu_average for basis set  ="
grep "mu_average for basis set  ="  ${ezfio}.DFT.out | tail -1 | cut -d "=" -f 2

