. ~/programs/qp_barth_last/quantum_package/quantum_package.rc
input_xyz=He.xyz
basis=aug-cc-pvdz
ezfio=He_aug-2z

qp_create_ezfio_from_xyz -b "${basis}" $input_xyz -o  $ezfio 
# First SCF calculation
qp_run SCF            $ezfio  | tee ${ezfio}.SCF_1.out 
##################################################################
## The following commands are useful only for tricky open shells 
##################################################################
# Brutal CIS in order to be sure to get the ground state 
qp_run cis            $ezfio  | tee ${ezfio}.CIS.out 
# Natural orbitals in order to ensure that the ground state is the "HF" filling 
qp_run save_natorb    $ezfio  | tee ${ezfio}.NAT.out 
# Last SCF calculation
qp_run SCF            $ezfio  | tee ${ezfio}.SCF_2.out 

# output : 
echo 
echo 
echo 
echo  "FINAL HF ENERGY = "
grep "* Hartree-Fock energy"  ${ezfio}.SCF_2.out | cut -d "y" -f 2
