# Loading the environment variables 
. ~/programs/qp_barth_last/quantum_package/quantum_package.rc

ezfio=$1
# expectations : 
#               $1 is a ezfio folder with a orthonormal orbitals (HF, DFT, etc ...)


#### a few inputs you will need  for the FCI 
#### the max number of Slater determinants 
ndet_max=10000000
echo $ndet_max > ${ezfio}/determinants/n_det_max
#### the minimum PT2 it will stop to 
pt2_max=0.000001
echo $pt2_max > ${ezfio}/perturbation/pt2_max

qp_run fci_zmq $ezfio  | tee ${ezfio}.FCI.out 

# output : 
echo 
echo 
echo 
echo "FINAL FCI ENERGY = "
grep "E+PT2           ="  ${ezfio}.FCI.out | tail -1 | cut -d "=" -f 2
